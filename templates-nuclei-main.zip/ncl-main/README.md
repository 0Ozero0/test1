# ncl
This is collections contains scripts to automate
 nuclie scan  and some templates.
